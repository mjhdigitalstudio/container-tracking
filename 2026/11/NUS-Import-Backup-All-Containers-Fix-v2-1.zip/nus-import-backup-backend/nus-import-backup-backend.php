<?php
/**
 * Plugin Name: NUS Import & Backup Backend
 * Description: Backend storage, import history and admin-only backup/restore endpoints for the National Umair Services Import & Backup page.
 * Version: 2.0.0
 */

if (!defined('ABSPATH')) exit;

final class NUS_Import_Backup_Backend {
    const VERSION = '2.0.0';

    public static function init() {
        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        register_deactivation_hook(__FILE__, [__CLASS__, 'deactivate']);

        add_action('nus_ib_daily_backup', [__CLASS__, 'cron_backup']);

        add_action('wp_ajax_nus_ib_import', [__CLASS__, 'ajax_import']);
        add_action('wp_ajax_nus_ib_history', [__CLASS__, 'ajax_history']);
        add_action('wp_ajax_nus_ib_create_backup', [__CLASS__, 'ajax_create_backup']);
        add_action('wp_ajax_nus_ib_list_backups', [__CLASS__, 'ajax_list_backups']);
        add_action('wp_ajax_nus_ib_download_backup', [__CLASS__, 'ajax_download_backup']);
        add_action('wp_ajax_nus_ib_restore_backup', [__CLASS__, 'ajax_restore_backup']);
        add_action('wp_ajax_nus_ib_delete_backup', [__CLASS__, 'ajax_delete_backup']);
        add_action('wp_ajax_nus_ib_sample', [__CLASS__, 'ajax_sample']);

        add_action('wp_footer', [__CLASS__, 'print_config'], 99);
    }

    private static function tables() {
        global $wpdb;
        return [
            'batches' => $wpdb->prefix . 'nus_import_batches',
            'rows'    => $wpdb->prefix . 'nus_import_rows',
            'data'    => $wpdb->prefix . 'nus_import_data',
            'backups' => $wpdb->prefix . 'nus_backups',
        ];
    }

    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $t = self::tables();
        $charset = $wpdb->get_charset_collate();

        $sql = [];
        $sql[] = "CREATE TABLE {$t['batches']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            file_name VARCHAR(255) NOT NULL,
            file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
            total_rows INT UNSIGNED NOT NULL DEFAULT 0,
            imported_rows INT UNSIGNED NOT NULL DEFAULT 0,
            skipped_rows INT UNSIGNED NOT NULL DEFAULT 0,
            error_rows INT UNSIGNED NOT NULL DEFAULT 0,
            status VARCHAR(40) NOT NULL DEFAULT 'Completed',
            mapping_json LONGTEXT NULL,
            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY created_at (created_at),
            KEY created_by (created_by)
        ) $charset;";

        $sql[] = "CREATE TABLE {$t['rows']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            batch_id BIGINT UNSIGNED NOT NULL,
            source_row INT UNSIGNED NOT NULL,
            status VARCHAR(30) NOT NULL,
            reason TEXT NULL,
            row_json LONGTEXT NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY batch_id (batch_id),
            KEY source_row (source_row)
        ) $charset;";

        $sql[] = "CREATE TABLE {$t['data']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            batch_id BIGINT UNSIGNED NOT NULL,
            record_type VARCHAR(60) NOT NULL DEFAULT 'container',
            data_json LONGTEXT NOT NULL,
            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY batch_id (batch_id),
            KEY record_type (record_type)
        ) $charset;";

        $sql[] = "CREATE TABLE {$t['backups']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            backup_name VARCHAR(255) NOT NULL,
            file_path TEXT NOT NULL,
            file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
            backup_type VARCHAR(30) NOT NULL DEFAULT 'Manual',
            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY created_at (created_at)
        ) $charset;";

        foreach ($sql as $statement) dbDelta($statement);

        update_option('nus_ib_version', self::VERSION, false);
        self::migrate_legacy_import_data();

        if (!wp_next_scheduled('nus_ib_daily_backup')) {
            $tz = wp_timezone();
            $next = new DateTime('now', $tz);
            $next->setTime(2, 0, 0);
            if ($next <= new DateTime('now', $tz)) {
                $next->modify('+1 day');
            }
            wp_schedule_event($next->getTimestamp(), 'daily', 'nus_ib_daily_backup');
        }
    }

    public static function deactivate() {
        $timestamp = wp_next_scheduled('nus_ib_daily_backup');
        if ($timestamp) wp_unschedule_event($timestamp, 'nus_ib_daily_backup');
    }

    private static function admin_guard() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Administrator permission is required.'], 403);
        }
        check_ajax_referer('nus_import_backup', 'nonce');
    }

    private static function clean_file_name($name) {
        $name = sanitize_file_name((string)$name);
        return $name ?: 'import-file';
    }

    private static function now() {
        return current_time('mysql');
    }

    public static function print_config() {
        if (!is_page('import-backup')) return;
        if (!is_user_logged_in()) return;
        ?>
        <script>
        window.NUS_IMPORT_BACKUP = <?php echo wp_json_encode([
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('nus_import_backup'),
            'isAdmin' => current_user_can('manage_options'),
            'maxFileSize' => 10 * 1024 * 1024,
        ]); ?>;
        </script>
        <?php
    }

    private static function normalize_import_date($value) {
        $value = trim((string)$value);
        if ($value === '') return '';
        $value = str_replace(['.', '/'], '-', $value);
        $formats = ['Y-m-d', 'd-m-Y', 'm-d-Y', 'Y-m-d H:i:s'];
        foreach ($formats as $format) {
            $dt = DateTime::createFromFormat($format, $value);
            $errors = DateTime::getLastErrors();
            $has_errors = is_array($errors) && ($errors['warning_count'] || $errors['error_count']);
            if ($dt && !$has_errors) return $dt->format('Y-m-d');
        }
        return '';
    }

    private static function clean_import_value($value) {
        return sanitize_text_field(is_scalar($value) ? (string)$value : '');
    }

    private static function find_container_by_number($container_no) {
        $container_no = strtoupper(preg_replace('/\s+/', '', (string)$container_no));
        if ($container_no === '') return 0;
        $ids = get_posts([
            'post_type' => 'nus_container',
            'post_status' => ['publish','private','draft','pending'],
            'posts_per_page' => 1,
            'fields' => 'ids',
            'meta_query' => [
                ['key' => 'container_no', 'value' => $container_no, 'compare' => '='],
            ],
        ]);
        return !empty($ids) ? (int)$ids[0] : 0;
    }

    private static function save_imported_container($data, $user_id) {
        $container_no = strtoupper(preg_replace('/\s+/', '', self::clean_import_value($data['container_number'] ?? '')));
        if (!preg_match('/^[A-Z]{4}\d{7}$/', $container_no)) {
            return ['ok'=>false, 'reason'=>'Container number must be 4 letters followed by 7 digits.'];
        }

        $entry_date = self::normalize_import_date($data['date'] ?? '');
        if ($entry_date === '') {
            return ['ok'=>false, 'reason'=>'Entry date is missing or invalid.'];
        }

        $shipping = self::clean_import_value($data['shipping_line'] ?? '');
        if ($shipping === '') {
            return ['ok'=>false, 'reason'=>'Shipping line is required.'];
        }

        $existing = self::find_container_by_number($container_no);
        if ($existing) {
            return ['ok'=>false, 'duplicate'=>true, 'reason'=>'Container already exists in All Containers.'];
        }

        $post_id = wp_insert_post([
            'post_type' => 'nus_container',
            'post_status' => 'publish',
            'post_title' => $container_no,
            'post_author' => $user_id,
        ], true);

        if (is_wp_error($post_id)) {
            return ['ok'=>false, 'reason'=>'Could not create container: '.$post_id->get_error_message()];
        }

        $meta = [
            'entry_date' => $entry_date,
            'container_no' => $container_no,
            'shipping_line' => $shipping,
            'booking_ref' => self::clean_import_value($data['booking_number'] ?? ''),
            'mobile' => self::clean_import_value($data['mobile'] ?? ''),
            'export_status' => self::clean_import_value($data['export_status'] ?? ''),
            'export_date' => self::normalize_import_date($data['export_date'] ?? ''),
            'bl_no' => self::clean_import_value($data['bl_number'] ?? ''),
            'vessel' => self::clean_import_value($data['vessel_voyage'] ?? ''),
            'customer' => self::clean_import_value($data['customer'] ?? ''),
            'seal_no' => self::clean_import_value($data['seal_number'] ?? ''),
            'arrival' => self::normalize_import_date($data['arrival_date'] ?? ''),
            'owner' => (int)$user_id,
            'verification_required' => 0,
            'container_status' => 'Active',
            'nus_imported' => 1,
            'nus_imported_at' => self::now(),
            'nus_import_batch_source' => sanitize_text_field($data['_import_batch'] ?? ''),
        ];

        $extra = [
            'shipment_id' => self::clean_import_value($data['shipment_id'] ?? ''),
            'remarks' => self::clean_import_value($data['remarks'] ?? ''),
            'free_days_until' => self::normalize_import_date($data['free_days_until'] ?? ''),
            'import_record_raw' => $data,
        ];
        $meta['extra_cols'] = wp_json_encode($extra, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        foreach ($meta as $key => $value) update_post_meta($post_id, $key, $value);

        update_post_meta($post_id, 'container_number', $container_no);
        update_post_meta($post_id, 'booking', $meta['booking_ref']);

        return ['ok'=>true, 'post_id'=>(int)$post_id];
    }

    private static function migrate_legacy_import_data() {
        global $wpdb;
        $t = self::tables();
        $table = $t['data'];
        $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($exists !== $table || !post_type_exists('nus_container')) return;

        $rows = $wpdb->get_results(
            "SELECT id, created_by, data_json FROM {$table} WHERE record_type IN ('container','register_entry') ORDER BY id ASC",
            ARRAY_A
        );
        if (!$rows) return;

        foreach ($rows as $row) {
            $data = json_decode((string)$row['data_json'], true);
            if (!is_array($data)) continue;
            $result = self::save_imported_container($data, (int)$row['created_by']);
            if (!empty($result['ok'])) {
                $data['_migrated_post_id'] = $result['post_id'];
                $wpdb->update($table,
                    ['data_json'=>wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)],
                    ['id'=>(int)$row['id']], ['%s'], ['%d']);
            }
        }
    }

    public static function ajax_import() {
        self::admin_guard();
        global $wpdb;

        $payload = json_decode(wp_unslash($_POST['payload'] ?? ''), true);
        if (!is_array($payload)) wp_send_json_error(['message'=>'Invalid import payload.'], 400);

        $file_name = self::clean_file_name($payload['fileName'] ?? 'import-file');
        $file_size = max(0, (int)($payload['fileSize'] ?? 0));
        $rows = isset($payload['rows']) && is_array($payload['rows']) ? $payload['rows'] : [];
        $mapping = isset($payload['mapping']) && is_array($payload['mapping']) ? $payload['mapping'] : [];
        $record_type = sanitize_key($payload['recordType'] ?? 'container');

        if (!$rows) wp_send_json_error(['message'=>'No rows supplied.'], 400);
        if ($file_size > 10*1024*1024) wp_send_json_error(['message'=>'File exceeds the 10 MB limit.'], 400);
        if (!in_array($record_type, ['container','register_entry','shipping_line','generic'], true)) $record_type='container';

        if ($record_type === 'container' || $record_type === 'register_entry') {
            self::migrate_legacy_import_data();
            if (!post_type_exists('nus_container')) {
                wp_send_json_error(['message'=>'The NUS Container Storage Backend is not active. Activate the existing container storage plugin first.'], 500);
            }
        }

        $t = self::tables();
        $user_id = get_current_user_id();
        $valid=0; $skipped=0; $errors=0; $batch_status='Completed';

        $wpdb->insert($t['batches'], [
            'file_name'=>$file_name,'file_size'=>$file_size,'total_rows'=>count($rows),
            'imported_rows'=>0,'skipped_rows'=>0,'error_rows'=>0,'status'=>'Processing',
            'mapping_json'=>wp_json_encode($mapping),'created_by'=>$user_id,'created_at'=>self::now(),
        ], ['%s','%d','%d','%d','%d','%d','%s','%s','%d','%s']);

        $batch_id=(int)$wpdb->insert_id;
        if (!$batch_id) wp_send_json_error(['message'=>'Could not create import batch.'],500);

        foreach ($rows as $i=>$item) {
            $source_row=(int)($item['sourceRow'] ?? ($i+2));
            $client_status=sanitize_key($item['status'] ?? 'valid');
            $client_reason=sanitize_textarea_field($item['reason'] ?? '');
            $data=isset($item['data']) && is_array($item['data']) ? $item['data'] : [];
            $data['_import_batch']=(string)$batch_id;
            $data['_created_by']=(int)$user_id;

            $status='valid'; $reason='';
            if ($record_type==='container' || $record_type==='register_entry') {
                $result=self::save_imported_container($data,$user_id);
                if (!empty($result['ok'])) $valid++;
                elseif (!empty($result['duplicate'])) { $status='duplicate'; $reason=$result['reason']; $skipped++; }
                else { $status='error'; $reason=$result['reason'] ?: $client_reason ?: 'Server validation failed.'; $errors++; }
            } else {
                if ($client_status==='duplicate') { $status='duplicate'; $reason=$client_reason ?: 'Duplicate row.'; $skipped++; }
                elseif ($client_status!=='valid') { $status='error'; $reason=$client_reason ?: 'Validation error.'; $errors++; }
                else {
                    $wpdb->insert($t['data'], [
                        'batch_id'=>$batch_id,'record_type'=>$record_type,
                        'data_json'=>wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
                        'created_by'=>$user_id,'created_at'=>self::now(),
                    ], ['%d','%s','%s','%d','%s']);
                    if ($wpdb->insert_id) $valid++;
                    else { $errors++; $status='error'; $reason='Database insert failed.'; }
                }
            }

            $wpdb->insert($t['rows'], [
                'batch_id'=>$batch_id,'source_row'=>$source_row,'status'=>$status,'reason'=>$reason,
                'row_json'=>wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
                'created_at'=>self::now(),
            ], ['%d','%d','%s','%s','%s','%s']);
        }

        if ($errors>0 && $valid>0) $batch_status='Completed with errors';
        elseif ($errors>0 && $valid===0) $batch_status='Failed';
        elseif ($skipped>0 && $valid===0) $batch_status='Completed with errors';

        $wpdb->update($t['batches'],[
            'imported_rows'=>$valid,'skipped_rows'=>$skipped,'error_rows'=>$errors,'status'=>$batch_status
        ],['id'=>$batch_id],['%d','%d','%d','%s'],['%d']);

        wp_send_json_success([
            'batchId'=>$batch_id,'imported'=>$valid,'skipped'=>$skipped,'errors'=>$errors,'status'=>$batch_status
        ]);
    }

    public static function ajax_history() {
        self::admin_guard();
        global $wpdb;
        $t = self::tables();

        $rows = $wpdb->get_results(
            "SELECT b.*, u.display_name
             FROM {$t['batches']} b
             LEFT JOIN {$wpdb->users} u ON u.ID=b.created_by
             ORDER BY b.created_at DESC
             LIMIT 100",
            ARRAY_A
        );

        $out = [];
        foreach ($rows as $r) {
            $out[] = [
                'id' => (int)$r['id'],
                'date' => mysql2date('d M Y, H:i', $r['created_at']),
                'file' => $r['file_name'],
                'importedBy' => $r['display_name'] ?: 'Admin',
                'imported' => (int)$r['imported_rows'],
                'skipped' => (int)$r['skipped_rows'],
                'errors' => (int)$r['error_rows'],
                'status' => $r['status'],
            ];
        }
        wp_send_json_success($out);
    }

    private static function make_backup_payload() {
        global $wpdb;
        $t = self::tables();

        $payload = [
            'version' => self::VERSION,
            'created_at' => self::now(),
            'site' => home_url('/'),
            'tables' => [],
        ];

        foreach ($t as $key => $table) {
            $payload['tables'][$key] = [
                'name' => $table,
                'rows' => $wpdb->get_results("SELECT * FROM {$table}", ARRAY_A),
            ];
        }

        $payload['options'] = [
            'nus_ib_version' => get_option('nus_ib_version'),
        ];

        return $payload;
    }

    public static function cron_backup() {
        if (!current_user_can('manage_options')) return;

        global $wpdb;
        $upload = wp_upload_dir();
        $dir = trailingslashit($upload['basedir']) . 'nus-backups';

        if (!wp_mkdir_p($dir)) return;

        $name = 'backup_' . current_time('Y-m-d_His') . '.json';
        $path = trailingslashit($dir) . $name;
        $payload = self::make_backup_payload();

        $written = file_put_contents(
            $path,
            wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );
        if ($written === false) return;

        $t = self::tables();
        $wpdb->insert($t['backups'], [
            'backup_name' => $name,
            'file_path' => $path,
            'file_size' => filesize($path),
            'backup_type' => 'Automatic',
            'created_by' => 0,
            'created_at' => self::now(),
        ], ['%s','%s','%d','%s','%d','%s']);
    }

    public static function ajax_create_backup() {
        self::admin_guard();
        global $wpdb;

        $upload = wp_upload_dir();
        $dir = trailingslashit($upload['basedir']) . 'nus-backups';

        if (!wp_mkdir_p($dir)) {
            wp_send_json_error(['message' => 'Could not create the backup directory.'], 500);
        }

        $name = 'backup_' . current_time('Y-m-d_His') . '.json';
        $path = trailingslashit($dir) . $name;
        $payload = self::make_backup_payload();

        $written = file_put_contents($path, wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        if ($written === false) wp_send_json_error(['message' => 'Could not write the backup file.'], 500);

        $t = self::tables();
        $wpdb->insert($t['backups'], [
            'backup_name' => $name,
            'file_path' => $path,
            'file_size' => filesize($path),
            'backup_type' => 'Manual',
            'created_by' => get_current_user_id(),
            'created_at' => self::now(),
        ], ['%s','%s','%d','%s','%d','%s']);

        wp_send_json_success(['message' => 'Backup created.', 'id' => (int)$wpdb->insert_id]);
    }

    public static function ajax_list_backups() {
        self::admin_guard();
        global $wpdb;
        $t = self::tables();

        $rows = $wpdb->get_results(
            "SELECT b.*, u.display_name
             FROM {$t['backups']} b
             LEFT JOIN {$wpdb->users} u ON u.ID=b.created_by
             ORDER BY b.created_at DESC
             LIMIT 100",
            ARRAY_A
        );

        $out = [];
        foreach ($rows as $r) {
            $out[] = [
                'id' => (int)$r['id'],
                'name' => $r['backup_name'],
                'created' => mysql2date('d M Y, H:i', $r['created_at']),
                'size' => size_format((int)$r['file_size']),
                'type' => $r['backup_type'],
            ];
        }
        wp_send_json_success($out);
    }

    private static function backup_by_id($id) {
        global $wpdb;
        $t = self::tables();
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['backups']} WHERE id=%d", $id), ARRAY_A);
    }

    public static function ajax_download_backup() {
        self::admin_guard();
        $id = absint($_POST['id'] ?? 0);
        $backup = self::backup_by_id($id);
        if (!$backup || !is_file($backup['file_path'])) wp_send_json_error(['message' => 'Backup not found.'], 404);

        $url = add_query_arg([
            'action' => 'nus_ib_download_backup_file',
            'id' => $id,
            '_wpnonce' => wp_create_nonce('nus_ib_download_file_' . $id),
        ], admin_url('admin-ajax.php'));

        wp_send_json_success(['url' => $url]);
    }

    public static function ajax_restore_backup() {
        self::admin_guard();
        global $wpdb;
        $id = absint($_POST['id'] ?? 0);
        $backup = self::backup_by_id($id);

        if (!$backup || !is_file($backup['file_path'])) wp_send_json_error(['message' => 'Backup not found.'], 404);

        $payload = json_decode(file_get_contents($backup['file_path']), true);
        if (!is_array($payload) || empty($payload['tables'])) wp_send_json_error(['message' => 'Invalid backup file.'], 400);

        $t = self::tables();
        $wpdb->query('START TRANSACTION');

        try {
            foreach (['data','rows','batches'] as $key) {
                $table = $t[$key];
                $wpdb->query("DELETE FROM {$table}");
                if (!empty($payload['tables'][$key]['rows'])) {
                    foreach ($payload['tables'][$key]['rows'] as $row) {
                        $formats = [];
                        foreach ($row as $value) $formats[] = is_numeric($value) && (string)(int)$value === (string)$value ? '%d' : '%s';
                        $wpdb->insert($table, $row, $formats);
                    }
                }
            }
            $wpdb->query('COMMIT');
        } catch (Throwable $e) {
            $wpdb->query('ROLLBACK');
            wp_send_json_error(['message' => 'Restore failed: ' . $e->getMessage()], 500);
        }

        wp_send_json_success(['message' => 'Backup restored successfully.']);
    }

    public static function ajax_delete_backup() {
        self::admin_guard();
        global $wpdb;
        $id = absint($_POST['id'] ?? 0);
        $backup = self::backup_by_id($id);
        if (!$backup) wp_send_json_error(['message' => 'Backup not found.'], 404);

        if (is_file($backup['file_path'])) @unlink($backup['file_path']);
        $wpdb->delete(self::tables()['backups'], ['id' => $id], ['%d']);
        wp_send_json_success(['message' => 'Backup deleted.']);
    }

    public static function ajax_sample() {
        self::admin_guard();
        $csv = "Container Number,Date,Shipping Line,Booking Number,Shipment ID,Mobile,Export Status,Export Date,Remarks\n";
        $csv .= "MSCU1234567,2026-10-23,MSC,BOOK123,SHIP123,03001234567,Pending,,Sample record\n";
        $csv .= "TCLU7654321,2026-10-24,Maersk,BOOK456,SHIP456,03111234567,Exported,2026-10-25,Sample record\n";

        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="nus-import-template.csv"');
        echo $csv;
        exit;
    }

    public static function download_file() {
        if (!current_user_can('manage_options')) wp_die('Forbidden', '', ['response' => 403]);
        $id = absint($_GET['id'] ?? 0);
        check_admin_referer('nus_ib_download_file_' . $id);

        $backup = self::backup_by_id($id);
        if (!$backup || !is_file($backup['file_path'])) wp_die('Backup not found.', '', ['response' => 404]);

        nocache_headers();
        header('Content-Type: application/json');
        header('Content-Length: ' . filesize($backup['file_path']));
        header('Content-Disposition: attachment; filename="' . basename($backup['file_path']) . '"');
        readfile($backup['file_path']);
        exit;
    }
}

NUS_Import_Backup_Backend::init();

add_action('wp_ajax_nopriv_nus_ib_download_backup_file', function() {
    wp_die('Forbidden', '', ['response' => 403]);
});
add_action('wp_ajax_nus_ib_download_backup_file', ['NUS_Import_Backup_Backend', 'download_file']);
