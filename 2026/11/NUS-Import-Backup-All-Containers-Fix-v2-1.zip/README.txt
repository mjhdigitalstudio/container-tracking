NUS Import & Backup Backend v2.0.0 — All Containers Integration

PURPOSE
This replacement backend keeps the existing Import & Backup page design/UI, but changes container imports so they are written into the existing NUS Container Management storage:

- CPT: nus_container
- container_no, entry_date, shipping_line, booking_ref, mobile, export_status, export_date
- bl_no, vessel, customer, seal_no, arrival
- owner/post_author = current logged-in Admin
- extra imported fields (shipment_id, remarks, free_days_until) are preserved in extra_cols

IMPORTANT
1. Back up WordPress/database first.
2. Deactivate the old "NUS Import & Backup Backend" plugin.
3. Install/activate this v2 plugin.
4. Keep "NUS Container Storage Backend" active.
5. Keep the existing Elementor Import & Backup page unchanged.
6. Clear cache / Ctrl+F5.

LEGACY IMPORT MIGRATION
On activation and before a new container import, the plugin scans the old wp_nus_import_data table and attempts to migrate previous container/register-entry rows into nus_container. Existing container numbers are skipped as duplicates.

SERVER-SIDE VALIDATION
Container number must be exactly 4 letters + 7 digits, e.g. MSCU1234567.
Entry Date is required and must be a real date.
Shipping Line is required.
Duplicates are checked against the actual All Containers CPT.

TEST
Use:
MSCU1234567
TCLU7654321
Then search those exact numbers in All Containers.

NOTE
The local build environment cannot access your live WordPress database, so the final live-site verification must be done in WordPress.
